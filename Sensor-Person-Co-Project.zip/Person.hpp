#ifndef PERSON_H
#define PERSON_H

#include<ctime>
#include<string>
#include<fstream>


class Person{
public:
  
  int getTimeWindow(int hour);

  void setAge(unsigned int);
	unsigned int getAge();
	
  void showPersonInfo(int);

  Person(const char *name);
	Person(const char *name, unsigned int age);

  int analyseSensedData(int timeWindow, int sampleValue, int age);

private:
  std::string name;
  unsigned int idNumber;
  unsigned int sampleTime;
  unsigned int sampleValue;
  unsigned int age;
  unsigned int timeWindow;
  unsigned int hour;
  unsigned int x;
};

#endif
